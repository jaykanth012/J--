"""A small, safe interpreter prototype for the J-- language (v0.3)."""
from __future__ import annotations

import ast
import operator
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

VERSION = "0.3"
MAX_STEPS = 10_000
MAX_BLOCK_DEPTH = 64
NAME_RE = r"[A-Za-z_][A-Za-z0-9_]*"

LET_RE = re.compile(rf"^let\s+({NAME_RE})\s*=\s*(.+);$")
ASSIGN_RE = re.compile(rf"^({NAME_RE})\s*=\s*(.+);$")
PRINT_RE = re.compile(r"^print\s*\((.*)\)\s*;$")
IF_RE = re.compile(r"^if\s+(.+?)\s*\{$")
WHILE_RE = re.compile(r"^while\s+(.+?)\s*\{$")
FOR_RE = re.compile(rf"^for\s+({NAME_RE})\s+in\s+range\s*\((.*)\)\s*\{{$")

RESERVED_NAMES = {
    "print", "input", "int", "float", "str", "range",
    "if", "else", "while", "for", "true", "false",
}

_BIN_OPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
}
_UNARY_OPS = {ast.UAdd: operator.pos, ast.USub: operator.neg}
_COMPARE_OPS = {
    ast.Eq: operator.eq,
    ast.NotEq: operator.ne,
    ast.Lt: operator.lt,
    ast.LtE: operator.le,
    ast.Gt: operator.gt,
    ast.GtE: operator.ge,
}


class JDashError(Exception):
    """An error in a J-- source program."""


@dataclass
class Statement:
    kind: str
    line: int
    expression: str = ""
    name: str = ""
    range_args: list[str] = field(default_factory=list)
    body: list["Statement"] = field(default_factory=list)
    else_body: list["Statement"] = field(default_factory=list)


class ExpressionReader:
    """Evaluate a deliberately small expression subset; never eval Python code."""

    def __init__(self, variables: dict[str, object], input_fn: Callable[[str], str]):
        self.variables = variables
        self.input_fn = input_fn

    def evaluate(self, expression: str) -> object:
        try:
            tree = ast.parse(expression, mode="eval")
            return self._node(tree.body)
        except JDashError:
            raise
        except (SyntaxError, ValueError, TypeError, ZeroDivisionError, OverflowError) as exc:
            raise JDashError(f"invalid expression: {exc}") from exc

    def _node(self, node: ast.AST) -> object:
        if isinstance(node, ast.Constant) and isinstance(node.value, (str, int, float, bool)):
            return node.value

        if isinstance(node, ast.Name):
            if node.id == "true":
                return True
            if node.id == "false":
                return False
            if node.id not in self.variables:
                raise JDashError(f"unknown variable '{node.id}'")
            return self.variables[node.id]

        if isinstance(node, ast.BinOp) and type(node.op) in _BIN_OPS:
            left = self._node(node.left)
            right = self._node(node.right)
            if isinstance(node.op, ast.Pow) and isinstance(right, (int, float)) and abs(right) > 100:
                raise JDashError("power exponent is too large (maximum absolute value: 100)")
            return _BIN_OPS[type(node.op)](left, right)

        if isinstance(node, ast.UnaryOp):
            if type(node.op) in _UNARY_OPS:
                return _UNARY_OPS[type(node.op)](self._node(node.operand))
            if isinstance(node.op, ast.Not):
                value = self._node(node.operand)
                if not isinstance(value, bool):
                    raise JDashError("not expects a boolean value")
                return not value

        if isinstance(node, ast.BoolOp) and isinstance(node.op, (ast.And, ast.Or)):
            values = []
            for item in node.values:
                value = self._node(item)
                if not isinstance(value, bool):
                    raise JDashError("and/or expects boolean values")
                values.append(value)
                if isinstance(node.op, ast.And) and not value:
                    return False
                if isinstance(node.op, ast.Or) and value:
                    return True
            return all(values) if isinstance(node.op, ast.And) else any(values)

        if isinstance(node, ast.Compare):
            left = self._node(node.left)
            for op_node, comparator in zip(node.ops, node.comparators):
                operation = _COMPARE_OPS.get(type(op_node))
                if operation is None:
                    raise JDashError("unsupported comparison; use ==, !=, <, <=, >, or >=")
                right = self._node(comparator)
                if not operation(left, right):
                    return False
                left = right
            return True

        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and not node.keywords:
            name = node.func.id
            args = [self._node(arg) for arg in node.args]
            if name == "input" and len(args) <= 1:
                prompt = args[0] if args else ""
                if not isinstance(prompt, str):
                    raise JDashError("input() prompt must be text")
                return self.input_fn(prompt)
            if name == "int" and len(args) == 1:
                return int(args[0])
            if name == "float" and len(args) == 1:
                return float(args[0])
            if name == "str" and len(args) == 1:
                return str(args[0])
            raise JDashError(f"unsupported function call '{name}()'")

        raise JDashError(
            "unsupported expression; use literals, variables, arithmetic, comparisons, "
            "and/or/not, or input/int/float/str"
        )


class Parser:
    """Parse line-oriented J-- statements and brace-delimited blocks."""

    def __init__(self, source: str):
        self.lines: list[tuple[int, str]] = []
        for line_number, raw in enumerate(source.splitlines(), start=1):
            line = raw.strip()
            # Permit the common compact spelling `} else {` while keeping blocks line-based.
            if re.fullmatch(r"}\s*else\s*\{", line):
                self.lines.append((line_number, "}"))
                self.lines.append((line_number, "else {"))
            else:
                self.lines.append((line_number, line))

    def parse(self) -> list[Statement]:
        statements, index = self._parse_block(0, opening_line=None, depth=0)
        if index != len(self.lines):
            line_number, line = self.lines[index]
            raise JDashError(f"Line {line_number}: unexpected '{line}'")
        return statements

    def _next_significant(self, index: int) -> int:
        while index < len(self.lines):
            _, line = self.lines[index]
            if line and not line.startswith("//"):
                break
            index += 1
        return index

    def _parse_block(
        self, index: int, opening_line: int | None, depth: int
    ) -> tuple[list[Statement], int]:
        if depth > MAX_BLOCK_DEPTH:
            line = opening_line or 1
            raise JDashError(f"Line {line}: block nesting is too deep (maximum: {MAX_BLOCK_DEPTH})")

        statements: list[Statement] = []
        while index < len(self.lines):
            line_number, line = self.lines[index]
            index += 1
            if not line or line.startswith("//"):
                continue
            if line == "}":
                if opening_line is None:
                    raise JDashError(f"Line {line_number}: unexpected closing brace '}}'")
                return statements, index
            if line == "else {" or line.startswith("else"):
                raise JDashError(f"Line {line_number}: 'else' must immediately follow an 'if' block")

            match = IF_RE.fullmatch(line)
            if match:
                body, index = self._parse_block(index, line_number, depth + 1)
                else_body: list[Statement] = []
                next_index = self._next_significant(index)
                if next_index < len(self.lines) and self.lines[next_index][1] == "else {":
                    index = next_index + 1
                    else_body, index = self._parse_block(index, self.lines[next_index][0], depth + 1)
                statements.append(Statement("if", line_number, expression=match.group(1), body=body, else_body=else_body))
                continue

            match = WHILE_RE.fullmatch(line)
            if match:
                body, index = self._parse_block(index, line_number, depth + 1)
                statements.append(Statement("while", line_number, expression=match.group(1), body=body))
                continue

            match = FOR_RE.fullmatch(line)
            if match:
                name, args_text = match.groups()
                if name in RESERVED_NAMES:
                    raise JDashError(f"Line {line_number}: '{name}' is a reserved name")
                try:
                    call = ast.parse(f"range({args_text})", mode="eval").body
                except SyntaxError as exc:
                    raise JDashError(f"Line {line_number}: invalid range() arguments") from exc
                if not isinstance(call, ast.Call) or not isinstance(call.func, ast.Name) or call.func.id != "range":
                    raise JDashError(f"Line {line_number}: use range(start, stop[, step])")
                if call.keywords or not 1 <= len(call.args) <= 3:
                    raise JDashError(f"Line {line_number}: range() accepts one, two, or three arguments")
                range_args = [ast.unparse(arg) for arg in call.args]
                body, index = self._parse_block(index, line_number, depth + 1)
                statements.append(Statement("for", line_number, name=name, range_args=range_args, body=body))
                continue

            if line.endswith("{"):
                raise JDashError(f"Line {line_number}: invalid block header")
            statements.append(Statement("simple", line_number, expression=line))

        if opening_line is not None:
            raise JDashError(f"Line {opening_line}: missing closing brace '}}'")
        return statements, index


class StepBudget:
    def __init__(self, maximum: int):
        if not isinstance(maximum, int) or isinstance(maximum, bool) or maximum < 1:
            raise ValueError("max_steps must be a positive integer")
        self.maximum = maximum
        self.used = 0

    def consume(self, line_number: int) -> None:
        self.used += 1
        if self.used > self.maximum:
            raise JDashError(
                f"Line {line_number}: execution limit exceeded ({self.maximum} steps); "
                "check your loop condition"
            )


def _run_simple(line: str, line_number: int, reader: ExpressionReader, output: list[str]) -> None:
    match = PRINT_RE.fullmatch(line)
    if match:
        output.append(str(reader.evaluate(match.group(1).strip())))
        return

    match = LET_RE.fullmatch(line) or ASSIGN_RE.fullmatch(line)
    if match:
        name, expression = match.groups()
        if name in RESERVED_NAMES:
            raise JDashError(f"'{name}' is a reserved name")
        is_declaration = line.startswith("let ")
        if not is_declaration and name not in reader.variables:
            raise JDashError(f"variable '{name}' is not declared; use let {name} = ...;")
        reader.variables[name] = reader.evaluate(expression.strip())
        return

    raise JDashError(
        "invalid syntax. Use let name = expression;, name = expression;, "
        "print(expression);, or a supported block"
    )


def _condition(expression: str, line_number: int, reader: ExpressionReader) -> bool:
    value = reader.evaluate(expression)
    if not isinstance(value, bool):
        raise JDashError(f"Line {line_number}: condition must be true or false")
    return value


def _execute_block(
    statements: list[Statement], reader: ExpressionReader, output: list[str], budget: StepBudget
) -> None:
    for statement in statements:
        budget.consume(statement.line)
        try:
            if statement.kind == "simple":
                _run_simple(statement.expression, statement.line, reader, output)
            elif statement.kind == "if":
                branch = statement.body if _condition(statement.expression, statement.line, reader) else statement.else_body
                _execute_block(branch, reader, output, budget)
            elif statement.kind == "while":
                while _condition(statement.expression, statement.line, reader):
                    budget.consume(statement.line)
                    _execute_block(statement.body, reader, output, budget)
            elif statement.kind == "for":
                values = [reader.evaluate(arg) for arg in statement.range_args]
                if any(not isinstance(value, int) or isinstance(value, bool) for value in values):
                    raise JDashError("range() arguments must be integers")
                try:
                    sequence = range(*values)
                except (ValueError, TypeError) as exc:
                    raise JDashError(f"invalid range(): {exc}") from exc
                try:
                    sequence_length = len(sequence)
                except OverflowError as exc:
                    raise JDashError(f"range() is too large (maximum iterations: {MAX_STEPS})") from exc
                if sequence_length > MAX_STEPS:
                    raise JDashError(f"range() is too large (maximum iterations: {MAX_STEPS})")
                for value in sequence:
                    budget.consume(statement.line)
                    reader.variables[statement.name] = value
                    _execute_block(statement.body, reader, output, budget)
        except JDashError as exc:
            message = str(exc)
            if message.startswith(f"Line {statement.line}:"):
                raise
            raise JDashError(f"Line {statement.line}: {message}") from exc
        except (TypeError, ValueError, ZeroDivisionError, OverflowError) as exc:
            raise JDashError(f"Line {statement.line}: {exc}") from exc


def execute(
    source: str,
    input_fn: Callable[[str], str] = input,
    max_steps: int = MAX_STEPS,
) -> list[str]:
    """Run J-- source and return printed lines without evaluating Python code."""
    statements = Parser(source).parse()
    variables: dict[str, object] = {}
    reader = ExpressionReader(variables, input_fn)
    output: list[str] = []
    _execute_block(statements, reader, output, StepBudget(max_steps))
    return output


def run_file(filename: str | Path) -> int:
    path = Path(filename)
    try:
        for line in execute(path.read_text(encoding="utf-8")):
            print(line)
    except FileNotFoundError:
        print(f"J-- error: file not found: {path}", file=sys.stderr)
        return 1
    except UnicodeDecodeError:
        print(f"J-- error: could not read {path} as UTF-8 text", file=sys.stderr)
        return 1
    except JDashError as exc:
        print(f"J-- error: {exc}", file=sys.stderr)
        return 1
    return 0


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python interpreter.py <program.j>", file=sys.stderr)
        return 2
    return run_file(sys.argv[1])


if __name__ == "__main__":
    raise SystemExit(main())
