# J-- Roadmap

## Implemented in v0.3
- Variables and reassignment
- Printing and browser-prompt input
- Arithmetic and comparisons
- Boolean `and`, `or`, `not`
- `if/else`, `while`, and `for ... in range(...)`
- Step and nesting limits in the Python interpreter
- Browser playground using the same Python interpreter

## Proposed future work (not implemented)
- v0.4: user-defined functions, parameters, and return values
- v0.5: improved diagnostics and a richer editor experience
- Later: modules, standard library, packaging, and native/mobile runtime exploration

Milestones are proposals, not promises. J-- remains an experimental prototype.
