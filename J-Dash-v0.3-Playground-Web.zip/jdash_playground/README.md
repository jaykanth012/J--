# J-- Playground v0.3

**J-- by Jaykanth V** — a browser-based editor for experimenting with the J-- v0.3 prototype.

## Run it

The playground loads Pyodide from a CDN and runs the existing Python interpreter in your browser. Keep `index.html` and `interpreter.py` in the same folder.

### Option A: GitHub Pages
1. Upload `index.html`, `interpreter.py`, and the `examples/` folder to the root of a GitHub repository.
2. Open **Settings → Pages**.
3. Select **Deploy from a branch**, choose `main` and `/(root)`, then save.
4. Open the published Pages URL. An internet connection is required on first load and to load the browser Python runtime.

### Option B: Run on a laptop
From this folder, run `python -m http.server 8000`, then open `http://localhost:8000`.

### Android
Extract the ZIP and upload its contents to GitHub using the GitHub website or app. Enable GitHub Pages as above, then open the Pages URL in Chrome. This package is a responsive web app, not an installable APK.

## Features supported
The playground uses the project `interpreter.py` directly, rather than a separate reimplementation. It supports the interpreter's implemented v0.3 syntax: `let`, reassignment, `print`, `input`, numeric/string conversions, arithmetic, comparisons, boolean operators, `if/else`, `while`, and `for ... in range(...)`.

## Example
```j--
let score = 82;
if score >= 50 {
    print("Pass");
} else {
    print("Try again");
}
for number in range(1, 4) {
    print(number);
}
```

## Notes and limitations
- Experimental learning playground; not a complete production language or native compiler.
- Browser runtime requires internet access to download Pyodide from its CDN.
- `input()` uses the browser's prompt dialog.
- Functions, classes, graphics, package management, and a dedicated Android APK are not implemented in v0.3.
