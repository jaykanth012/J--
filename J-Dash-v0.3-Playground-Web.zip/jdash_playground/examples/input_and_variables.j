// J-- v0.3 example: variables, input, and arithmetic
let name = input("What is your name? ");
let first = 12;
let second = 8;
let total = first + second;
print("Hello, " + name + "!");
print("12 + 8 = " + str(total));
