// J-- v0.3 example: conditions and loops
let score = 82;

if score >= 50 {
    print("Pass");
} else {
    print("Try again");
}

let count = 1;
while count <= 3 {
    print("While count: " + str(count));
    count = count + 1;
}

for number in range(1, 4) {
    print("For number: " + str(number));
}
